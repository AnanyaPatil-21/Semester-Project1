/* =====================================================
   CAMPUSPLUS - STUDENT ANNOUNCEMENTS
   ===================================================== */

document.addEventListener("DOMContentLoaded", function () {

    const searchInput =
        document.getElementById("announcementSearch");

    const clearButton =
        document.getElementById("clearAnnouncementSearch");

    const filterButtons =
        document.querySelectorAll(".announcement-filter");

    const cards =
        document.querySelectorAll(".announcement-card");

    const noAnnouncements =
        document.getElementById("noAnnouncements");

    const countElement =
        document.getElementById("announcementCount");


    let currentFilter = "all";


    /* ================= FILTER FUNCTION ================= */

    function updateAnnouncements() {

        const searchText =
            searchInput.value.toLowerCase().trim();

        let visibleCount = 0;


        cards.forEach(function (card) {

            const category =
                card.dataset.category;

            const content =
                card.textContent.toLowerCase();


            const matchesSearch =
                content.includes(searchText);


            const matchesFilter =
                currentFilter === "all" ||
                category === currentFilter;


            if (matchesSearch && matchesFilter) {

                card.style.display = "flex";

                visibleCount++;

            } else {

                card.style.display = "none";

            }

        });


        /* No result message */

        if (visibleCount === 0) {

            noAnnouncements.style.display = "block";

        } else {

            noAnnouncements.style.display = "none";

        }


        /* Update count */

        if (countElement) {

            countElement.textContent =
                visibleCount + " Updates";

        }

    }


    /* ================= SEARCH ================= */

    searchInput.addEventListener(
        "input",
        updateAnnouncements
    );


    /* ================= CLEAR SEARCH ================= */

    clearButton.addEventListener(
        "click",
        function () {

            searchInput.value = "";

            updateAnnouncements();

            searchInput.focus();

        }
    );


    /* ================= FILTER ================= */

    filterButtons.forEach(function (button) {

        button.addEventListener(
            "click",
            function () {

                filterButtons.forEach(function (btn) {

                    btn.classList.remove("active");

                });


                button.classList.add("active");


                currentFilter =
                    button.dataset.filter;


                updateAnnouncements();

            }
        );

    });


    /* Initial */

    updateAnnouncements();

});